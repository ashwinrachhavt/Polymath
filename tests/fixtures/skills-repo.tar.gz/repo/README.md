# Skills repo

Fixtures for the GitHub adapter.
