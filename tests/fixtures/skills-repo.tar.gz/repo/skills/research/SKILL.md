---
name: research
description: Digs through sources and keeps the citations.
---

1. Open the source.
2. Note the claim and its evidence.
3. Keep the checklist beside the notes.
